jQuery(document).ready(function(){
	
	/*
	 *
	 * NHP_Options_date function
	 * Adds datepicker js
	 *
	 */
	jQuery('.simple-options-datepicker').datepicker();
	
});